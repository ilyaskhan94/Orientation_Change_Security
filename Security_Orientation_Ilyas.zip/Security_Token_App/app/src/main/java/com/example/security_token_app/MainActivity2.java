package com.example.security_token_app;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

public class MainActivity2 extends AppCompatActivity
{
    SharedPreferences sharedPreferences;
    private static String SHARED_PREF_NAME = "SharedPrefFile";
    private static String TIMESTAMP_KEY = "TIMESTAMP_KEY";
    ArrayList<String> arrayList = new ArrayList<String>();
    ListView listView;
    Button clearButton;
    int count;
    String item;
    static ArrayAdapter<String> adapter;
    static boolean isSaved = false;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        listView = (ListView) findViewById(R.id.listView1);
        clearButton = (Button) findViewById(R.id.passButton);
        sharedPreferences = getSharedPreferences(SHARED_PREF_NAME,MODE_PRIVATE);

        ArrayList<String> timestampList = (ArrayList<String>)getIntent().getSerializableExtra("timestamp_list");
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, timestampList);
        listView.setAdapter(adapter);

        clearButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                count = adapter.getCount();
                String checkFirstPass = sharedPreferences.getString(TIMESTAMP_KEY,null);
                Log.i("k2","timestamp: "+checkFirstPass);
                if(checkFirstPass==null)
                {
                    item = adapter.getItem(count - 1);
                }
                else if(checkFirstPass!=null)
                {
                    item = adapter.getItem(count-2);
                }
                adapter.clear();
                adapter.add(item);
                saveTimeStamp(item);
            }
        });
    }

    public void saveTimeStamp(String lastItem)
    {
        if(!lastItem.isEmpty())
        {
            sharedPreferences = getSharedPreferences(SHARED_PREF_NAME,MODE_PRIVATE);
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString(TIMESTAMP_KEY, lastItem);
            editor.apply();
            Toast.makeText(getBaseContext(), "time stamp saved", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(getBaseContext(), "nothing saved", Toast.LENGTH_SHORT).show();
        }
    }
}