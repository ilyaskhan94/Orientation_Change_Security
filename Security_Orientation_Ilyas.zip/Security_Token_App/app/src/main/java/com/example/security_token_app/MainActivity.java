package com.example.security_token_app;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.PersistableBundle;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity
{
    private static String SHARED_PREF_NAME = "SharedPrefFile";
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    private static String TIMESTAMP_KEY = "TIMESTAMP_KEY";
    TextView countDownTextView;
    TextView passCodeTextView;
    int passCode; //was static
    String timeStamp;
    String currentDateTime; //was static
    ArrayList<String> arrayIntegerList = new ArrayList<String>(); // was static
    Button verifyButton;
    CountDownTimer countDownTimer;
    long timeLeftInMillis = 60000;
    long tempTimeLeftInMillis;
    boolean firstPass = false;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    { //need if in savedInstance state ?
        super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            countDownTextView = (TextView) findViewById(R.id.textView4_time_remaining);
            passCodeTextView = (TextView) findViewById(R.id.textView3_passCode_int);
            verifyButton = (Button) findViewById(R.id.button1);
            sharedPreferences = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);

            createPassCode();
//            countDownTimer = new CountDownTimer(60000, 1000) // was 1000
//            {
//                @Override
//                public void onTick(long timeUntillFinished)
//                {
//                    timeLeftInMillis = timeUntillFinished;
//                    countDownTextView.setText("seconds remaining: " + timeUntillFinished / 1000 % 60);
//
//                }
//
//                @Override
//                public void onFinish()
//                {
//                    createPassCode();
//                    start();
//                }
//            }.start();
            startTimer();
            verifyButton.setOnClickListener(new View.OnClickListener()
            {
                @Override
                public void onClick(View view)
                {
                    String check = sharedPreferences.getString(TIMESTAMP_KEY, null);
                    Log.i("k1", "timestamp: " + check);
                    if (check != null)
                    {
                        arrayIntegerList.add(check);
                        Toast.makeText(getBaseContext(), "restored", Toast.LENGTH_SHORT).show();
                    }
                    openSecondaryActivity();
                }
            });

    }

    public void createPassCode()
    {
        int minute = Calendar.getInstance().get(Calendar.MINUTE);
        passCode=minute*1245 + 10000;
        timeStamp = getTimeStamp();
        arrayIntegerList.add(timeStamp);
        String passCodeStr = Integer.toString(passCode);
        passCodeTextView.setText(passCodeStr);
    }

    public void openSecondaryActivity()
    {
        Intent intent = new Intent(this, MainActivity2.class);
        intent.putExtra("timestamp_list", arrayIntegerList);
        startActivity(intent);
    }

    public int getPassCode() //was static
    {
        return passCode;
    }

    public String getTimeStamp() //was static
    {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        currentDateTime = dateFormat.format(new Date());
        return currentDateTime;
    }

    public void startTimer()
    {
        if(firstPass==true)
        {
            timeLeftInMillis=60000;
        }
        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) //was 1000
        {
            @Override
            public void onTick(long timeUntillFinished)
            {
                timeLeftInMillis = timeUntillFinished;
                countDownTextView.setText("seconds remaining: " + timeLeftInMillis / 1000 % 60); //was + timeUntillFinished

            }

            @Override
            public void onFinish()
            {   firstPass = true;
                timeLeftInMillis = 60000;
                createPassCode();
                start();
            }
        }.start();
    }


    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState)
    {
        super.onSaveInstanceState(outState);
        outState.putLong("timeLeftInMillis_key", timeLeftInMillis);
        outState.putInt("passCode_key", passCode);
        outState.putString("timeStamp_key", timeStamp);
        outState.putStringArrayList("arrayList_key", arrayIntegerList);
        Toast.makeText(getBaseContext(), "savedState", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        //countDownTextView = (TextView) findViewById(R.id.textView4_time_remaining);
        timeLeftInMillis = savedInstanceState.getLong("timeLeftInMillis_key");
        countDownTextView.setText("seconds remaining: " + timeLeftInMillis / 1000 % 60);
        startTimer();
        passCode = savedInstanceState.getInt("passCode_key");
        timeStamp = savedInstanceState.getString("timeStamp_key");
        arrayIntegerList = savedInstanceState.getStringArrayList("arrayList_key");
        Toast.makeText(getBaseContext(), "restoredState", Toast.LENGTH_SHORT).show();
    }

}